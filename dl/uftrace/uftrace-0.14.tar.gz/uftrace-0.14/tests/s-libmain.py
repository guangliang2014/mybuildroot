#!/usr/bin/python3
import mymod

def myfunc():
    mymod.public_func()

if __name__ == '__main__':
    myfunc()
