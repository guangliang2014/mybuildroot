#! /bin/sh
mkdir -p m4 && \
touch ChangeLog && \
autoreconf -s -f -i
