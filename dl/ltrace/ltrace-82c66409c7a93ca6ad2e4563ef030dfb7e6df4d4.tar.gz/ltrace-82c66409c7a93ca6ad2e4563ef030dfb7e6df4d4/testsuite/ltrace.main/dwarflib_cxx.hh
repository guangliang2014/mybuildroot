#ifndef DWARFLIB_CXX_HH
#define DWARFLIB_CXX_HH

#ifdef __cplusplus
extern "C"
#endif

void enum_cxx_test(void);

#endif
