/* ISC license. */

#include <skalibs/genwrite.h>

int genwrite_flush_stralloc (void *target)
{
  (void)target ;
  return 1 ;
}
