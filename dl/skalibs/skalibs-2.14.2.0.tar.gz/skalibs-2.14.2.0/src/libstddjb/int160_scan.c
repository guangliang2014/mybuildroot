/* ISC license. */

#include <skalibs/uint16.h>
#include "fmtscan-internal.h"

SCANS0(16)
