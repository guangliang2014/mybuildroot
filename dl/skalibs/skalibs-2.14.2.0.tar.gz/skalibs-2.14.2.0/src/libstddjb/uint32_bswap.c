/* ISC license. */

#include <skalibs/uint32.h>

uint32_t uint32_bswap (uint32_t a)
{
  return UINT32_BSWAP(a) ;
}
