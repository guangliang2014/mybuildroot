/* ISC license. */

#include <skalibs/uint16.h>

uint16_t uint16_bswap (uint16_t a)
{
  return UINT16_BSWAP(a) ;
}
