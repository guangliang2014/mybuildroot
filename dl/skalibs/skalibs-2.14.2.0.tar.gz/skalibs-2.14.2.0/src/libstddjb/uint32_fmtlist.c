/* ISC license. */

#include <skalibs/uint32.h>
#include "fmtscan-internal.h"

FMTL(32)
