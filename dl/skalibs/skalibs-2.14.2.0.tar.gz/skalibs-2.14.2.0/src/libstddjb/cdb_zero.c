/* ISC license. */

#include <skalibs/cdb.h>

cdb const cdb_zero = CDB_ZERO ;
