/* ISC license. */

/* MT-unsafe */

#include <skalibs/strerr.h>

char const *PROG = "(none)" ;
