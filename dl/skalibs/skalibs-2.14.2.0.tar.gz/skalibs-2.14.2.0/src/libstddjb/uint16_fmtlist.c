/* ISC license. */

#include <skalibs/uint16.h>
#include "fmtscan-internal.h"

FMTL(16)
