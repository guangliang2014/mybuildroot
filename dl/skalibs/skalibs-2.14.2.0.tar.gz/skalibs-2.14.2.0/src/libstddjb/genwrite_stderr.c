/* ISC license. */

#include <skalibs/buffer.h>
#include <skalibs/genwrite.h>

genwrite genwrite_stderr = GENWRITE_BUFFER_INIT(buffer_2) ;
