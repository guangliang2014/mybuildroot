/* ISC license. */

#include <skalibs/stralloc.h>
#include <skalibs/skamisc.h>

stralloc satmp = STRALLOC_ZERO ;
