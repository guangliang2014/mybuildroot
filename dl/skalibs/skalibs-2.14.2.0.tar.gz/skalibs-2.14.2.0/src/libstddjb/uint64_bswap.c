/* ISC license. */

#include <skalibs/uint64.h>

uint64_t uint64_bswap (uint64_t a)
{
  return UINT64_BSWAP(a) ;
}
