/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint64.h>

SCANL(64)
