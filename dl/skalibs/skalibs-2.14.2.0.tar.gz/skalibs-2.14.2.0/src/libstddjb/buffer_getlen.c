/* ISC license. */

#include <skalibs/buffer.h>

size_t buffer_getlen (buffer const *b)
{
  return buffer_len(b) ;
}
