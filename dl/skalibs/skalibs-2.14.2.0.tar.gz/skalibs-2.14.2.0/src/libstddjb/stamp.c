/* ISC license. */

/* MT-unsafe */

#include <skalibs/tai.h>

tain STAMP = TAIN_EPOCH ;
