/* ISC license. */

/* MT-unsafe */

#include <skalibs/sgetopt.h>

subgetopt subgetopt_here = SUBGETOPT_ZERO ;
