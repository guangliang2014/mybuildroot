/* ISC license. */

#include <skalibs/tai.h>

tain const tain_infinite = TAIN_INFINITE ;
