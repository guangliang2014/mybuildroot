/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint32.h>

SCANL(32)
