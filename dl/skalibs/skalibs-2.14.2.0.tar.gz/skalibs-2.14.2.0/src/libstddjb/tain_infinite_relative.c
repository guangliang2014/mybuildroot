/* ISC license. */

#include <skalibs/tai.h>

tain const tain_infinite_relative = TAIN_INFINITE_RELATIVE ;
