/* ISC license. */

#include <skalibs/buffer.h>
#include <skalibs/genwrite.h>

genwrite genwrite_stdout = GENWRITE_BUFFER_INIT(buffer_1) ;
