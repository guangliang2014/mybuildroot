#include <tracefs.h>

int main()
{
	tracefs_tracing_dir();
	return 0;
}
