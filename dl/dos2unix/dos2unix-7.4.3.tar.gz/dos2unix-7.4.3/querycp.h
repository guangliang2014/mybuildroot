/* querycp.h is in the public domain */

unsigned short query_con_codepage(void);
