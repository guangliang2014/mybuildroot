#ifndef CONFIG_STRSEP

#ifndef FIO_STRSEP_LIB_H
#define FIO_STRSEP_LIB_H

char *strsep(char **, const char *);

#endif

#endif
