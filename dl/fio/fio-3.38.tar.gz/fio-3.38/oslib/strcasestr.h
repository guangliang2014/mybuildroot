#ifndef CONFIG_STRCASESTR

#ifndef FIO_STRCASESTR_H
#define FIO_STRCASESTR_H

char *strcasestr(const char *haystack, const char *needle);

#endif

#endif
