#include <event-parse.h>

int main ()
{
	tep_load_plugins(NULL);
	return 0;
}
